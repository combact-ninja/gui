# --- Import Necessary modules
import keras.utils
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from MODELS import Auto_Encoder
from skmultiflow.drift_detection import DDM, ADWIN


data = pd.read_csv('Train_data.csv')
for col in data.columns:
    if data[col].dtype == 'object':
        label_encoder = LabelEncoder()
        data[col] = label_encoder.fit_transform(data[col])

X = data.drop('class', axis=1)
Y = data['class']
for col in X.select_dtypes(include=[np.number]).columns:
    X[col] = np.log(X[col] + 1)

feat = np.array(X)
lab = np.array(Y)

xtrain, xtest, ytrain, ytest = train_test_split(feat, lab, train_size=0.70, random_state=2)
print(xtrain.shape, xtest.shape, ytrain.shape, ytest.shape)
ytrain = keras.utils.to_categorical(ytrain)

model = Auto_Encoder(xtrain, ytrain)

model.fit(xtrain, ytrain, epochs=10, batch_size=32)
ypred = model.predict(xtest)
print(accuracy_score(ytest, np.argmax(ypred, axis=1)))
# Model summary
model.summary()




# Initialize the drift detector (DDM or ADWIN)
ddm = DDM()  # Or use ADWIN() instead of DDM()

# Assuming ytest is a stream of true labels and ypred is the predicted output
# For each prediction, update the drift detector
for true_label, prediction in zip(ytest, np.argmax(ypred, axis=1)):
    # Check if the drift detector has detected any drift
    ddm.add_element(true_label == prediction)  # You can pass a boolean: True if correct, False if incorrect

    if ddm.detected_change():
        print(f"Change detected at index {i}")

# You can also use ADWIN in a similar way, simply by replacing DDM() with ADWIN()