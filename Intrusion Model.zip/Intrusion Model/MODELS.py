from keras import Model
from keras.layers import *
import tensorflow as tf


class SelfAttention(Layer):
    def __init__(self, **kwargs):
        super(SelfAttention, self).__init__(**kwargs)
        self.query_dense = None
        self.key_dense = None
        self.value_dense = None
        self.attention_weights = None

    def build(self, input_shape):
        self.query_dense = Dense(input_shape[-1])  # Query layer
        self.key_dense = Dense(input_shape[-1])  # Key layer
        self.value_dense = Dense(input_shape[-1])  # Value layer
        super(SelfAttention, self).build(input_shape)

    def call(self, inputs):
        # Query, Key, Value matrices
        Q = self.query_dense(inputs)
        K = self.key_dense(inputs)
        V = self.value_dense(inputs)

        # Compute attention scores
        scores = tf.matmul(Q, K, transpose_b=True)
        d_k = tf.cast(K.shape[-1], tf.float32)
        scaled_scores = scores / tf.sqrt(d_k)

        # Softmax to get attention weights
        attention_weights = tf.nn.softmax(scaled_scores, axis=-1)

        # Weighted sum of values
        output = tf.matmul(attention_weights, V)

        return output


class CrossAttention(Layer):
    def __init__(self, **kwargs):
        super(CrossAttention, self).__init__(**kwargs)
        self.query_dense = None
        self.key_dense = None
        self.value_dense = None
        self.attention_weights = None

    def build(self, input_shape):
        self.query_dense = Dense(input_shape[-1])  # Query layer
        self.key_dense = Dense(input_shape[-1])  # Key layer
        self.value_dense = Dense(input_shape[-1])  # Value layer
        super(CrossAttention, self).build(input_shape)

    def call(self, inputs):
        # Query, Key, Value matrices
        Q = self.query_dense(inputs)
        K = self.key_dense(inputs)
        V = self.value_dense(inputs)

        # Compute attention scores
        scores = tf.matmul(Q, K, transpose_b=True)
        d_k = tf.cast(K.shape[-1], tf.float32)
        scaled_scores = scores / tf.sqrt(d_k)

        # Softmax to get attention weights
        attention_weights = tf.nn.softmax(scaled_scores, axis=-1)

        # Weighted sum of values
        output = tf.matmul(attention_weights, V)
        output = output + inputs

        return output





def Auto_Encoder(xtrain, ytrain):
    input_layer = Input(shape=(xtrain.shape[1]))
    # Encoder
    encoded = Dense(256, activation='relu')(input_layer)
    encoded = Dense(128, activation='relu')(encoded)
    encoded = Dense(64, activation='relu')(encoded)
    encoded = Dense(32, activation='relu')(encoded)
    # Latent space (bottleneck)
    latent = Dense(16, activation='relu')(encoded)
    # ----------- Attention -----------
    att1 = SelfAttention()(latent)
    att2 = CrossAttention()(att1)
    #----------------------------------
    # Decoder
    decoded = Dense(32, activation='relu')(att2)
    decoded = Dense(64, activation='relu')(decoded)
    decoded = Dense(128, activation='relu')(decoded)
    decoded = Dense(256, activation='relu')(decoded)

    # Output layer (same shape as the input)

    dense_layer = Dense(64, activation='relu')(decoded)
    dense_layer = Dense(32, activation='relu')(dense_layer)
    dense_layer = Dense(16, activation='relu')(dense_layer)
    output_layer = Dense(ytrain.shape[1], activation='softmax')(dense_layer)
    # Build autoencoder model
    autoencoder = Model(inputs=input_layer, outputs=output_layer)
    # Compile the model
    autoencoder.compile(optimizer='adam', loss='categorical_crossentropy', metrics='accuracy')
    return autoencoder
