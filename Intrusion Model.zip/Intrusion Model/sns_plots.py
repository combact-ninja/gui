# --- Import Necessary modules
import keras.utils
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from MODELS import Auto_Encoder
import seaborn as sns
import matplotlib.pyplot as plt




data = pd.read_csv('Train_data.csv')
for col in data.columns:
    if data[col].dtype == 'object':
        label_encoder = LabelEncoder()
        data[col] = label_encoder.fit_transform(data[col])

X = data.drop('class', axis=1)
Y = data['class']
for col in X.select_dtypes(include=[np.number]).columns:
    X[col] = np.log(X[col] + 1)

feat = np.array(X)
lab = np.array(Y)


# ---------------- pair plot ------------
sns.pairplot(data)
plt.show()
plt.savefig('pair_plot.png')
# ---------------- Calculate correlation matrix -----
corr = data.corr()
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.show()
plt.savefig('corr.png')
# ------------------- count plot -----------
sns.countplot(x='class', data=data)
plt.show()
plt.savefig('count.png')

# # ----------------- facetgrid ---------
# g = sns.FacetGrid(data, col='class')
# g.map(sns.histplot, 'numerical_column')
# plt.show()